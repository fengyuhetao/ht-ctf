#/bin/bash
sudo ./qemu-system-x86_64 -L ./dependences -initrd ./rootfs.cpio -kernel ./vmlinuz-4.13.0-37-generic -append 'console=ttyS0 root=/dev/ram oops=panic panic=1' -enable-kvm -m 56M --nographic
